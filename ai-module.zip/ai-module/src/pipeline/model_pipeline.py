import numpy as np
import pandas as pd
from typing import Union, List

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sklearn.impute import KNNImputer
from sklearn.preprocessing import RobustScaler
from sklearn.linear_model import ElasticNet
import xgboost as xgb
import lightgbm as lgb


class ClinicalOutlierClipper(BaseEstimator, TransformerMixin):
    """
    Transformeur personnalisé (Scikit-learn compatible) pour le traitement conditionnel des valeurs aberrantes.
    Méthode : Winsorisation basée sur l'Écart Interquartile (IQR) par matrice.
    Protège la modélisation asymptotique contre les dysfonctionnements passagers des senseurs
    physiologiques tout en ignorant intentionnellement les données manquantes lors de la robustesse.
    """
    def __init__(self, multiplier: float = 3.0):
        self.multiplier = multiplier
        self.lower_bounds_: List[float] = []
        self.upper_bounds_: List[float] = []
        
    def fit(self, X: Union[pd.DataFrame, np.ndarray], y=None):
        X_array = np.asarray(X)
        self.lower_bounds_ = []
        self.upper_bounds_ = []
        
        # Isolation topologique colonne par colonne
        for i in range(X_array.shape[1]):
            col_data = X_array[:, i]
            # Exclusion des valeurs NaN pour le calcul asymptotique de l'IQR
            valid_data = col_data[~np.isnan(col_data)]
            
            if len(valid_data) == 0:
                self.lower_bounds_.append(-np.inf)
                self.upper_bounds_.append(np.inf)
                continue
                
            q1 = np.percentile(valid_data, 25)
            q3 = np.percentile(valid_data, 75)
            iqr = q3 - q1
            self.lower_bounds_.append(q1 - self.multiplier * iqr)
            self.upper_bounds_.append(q3 + self.multiplier * iqr)
            
        return self

    def transform(self, X: Union[pd.DataFrame, np.ndarray]) -> np.ndarray:
        """
        Application vectorisée de l'écrêtage statique garantissant la gestion des exceptions
        en < 1ms, quel que soit le nombre de signaux physiologiques injectés.
        """
        X_array = np.asarray(X).copy()
        
        # Le backend C de numpy gère intrinsèquement la préservation des NaNs
        # et le BroadCasting dynamique pour une application immédiate sur toutes les colonnes.
        return np.clip(X_array, self.lower_bounds_, self.upper_bounds_)


class MetabolicRiskPipeline:
    """
    Fabrique (Factory) d'assemblage du pipeline computationnel End-to-End.
    Permet la génération structurale d'un acyclic graph (Transformation -> Inférence).
    Conçu pour un export unifié et strict (sérialisation ONNX).
    """
    
    SUPPORTED_MODELS = ["elasticnet", "xgboost", "lightgbm"]
    
    def __init__(self, model_type: str = "xgboost"):
        """
        Args:
            model_type: Définit le noyau algorithmique ciblé.
        """
        if model_type not in self.SUPPORTED_MODELS:
            raise ValueError(f"Topologie d'algorithme '{model_type}' non supportée. Prévu: {self.SUPPORTED_MODELS}")
        self.model_type = model_type
        
    def _build_preprocessor(self) -> Pipeline:
        """
        Définit la strate de normalisation physiologique :
        1. KNNImputer : Estimation multivariée exploitant les matrices des covariables.
        2. RobustScaler : Centrage-réduction résilient face à la variance non-normale.
        """
        return Pipeline([
            ("imputer", KNNImputer(n_neighbors=5, weights="distance")),
            ("scaler", RobustScaler(with_centering=True, with_scaling=True))
        ])
        
    def _build_estimator(self) -> BaseEstimator:
        """
        Instancie le moteur d'apprentissage supervisé (Estimator) avec des hyperparamètres 
        initiaux stables, destinés à une régularisation via Hyper-parameter Tuning (Optuna en aval).
        """
        if self.model_type == "elasticnet":
            # Baseline régularisée l1/l2 (pénalité conjointe stricte). Maximum Explicabilité.
            return ElasticNet(
                alpha=1.0, 
                l1_ratio=0.5, 
                max_iter=5000, 
                random_state=42
            )
        elif self.model_type == "xgboost":
            # Extreme Gradient Boosting
            # Regressor asymétrique pour modélisation haute fréquence.
            return xgb.XGBRegressor(
                objective="reg:squarederror",
                n_estimators=100,
                learning_rate=0.05,
                max_depth=5,
                random_state=42,
                n_jobs=-1
            )
        elif self.model_type == "lightgbm":
            # Regressor Leaf-wise LightGBM, optimisé pour inférence sous 50ms et très grandes dimensions.
            return lgb.LGBMRegressor(
                objective="regression",
                n_estimators=100,
                learning_rate=0.05,
                max_depth=5,
                random_state=42,
                n_jobs=-1,
                verbose=-1
            )
        else:
            raise NotImplementedError()

    def get_pipeline(self) -> Pipeline:
        """
        Aggrégation scikit-learn standard. Fournit le composant computationnel global.
        Returns:
            Pipeline: Le flux mathématique complet prêt pour `fit()` et `predict()`.
        """
        pipeline = Pipeline([
            # 1. Borne géométrique des bruits intenses
            ("outlier_clipper", ClinicalOutlierClipper(multiplier=4.0)),
            # 2. Remplissage spatial + Standardisation de distribution
            ("preprocessor", self._build_preprocessor()),
            # 3. Mapping non-linéaire vers le scalaire attendu
            ("estimator", self._build_estimator())
        ])
        
        return pipeline
