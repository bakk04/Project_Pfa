import os
import sys
import yaml
import json
import joblib
import hashlib
import logging
import warnings
import numpy as np
import pandas as pd
import shap
import mlflow
import mlflow.sklearn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Tuple, Optional, Any

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.metrics import (
    roc_auc_score, brier_score_loss, classification_report,
    roc_curve, average_precision_score, confusion_matrix
)
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.preprocessing import label_binarize
import optuna
from optuna.samplers import TPESampler
from optuna.pruners import HyperbandPruner

# Conformal Prediction
from mapie.classification import MapieClassifier
from mapie.metrics import classification_coverage_score

# Imbalanced learning
from imblearn.over_sampling import SMOTENC

warnings.filterwarnings("ignore", category=optuna.exceptions.ExperimentalWarning)

# ---------------------------------------------------------
# LOGGING — Structured JSON pour audit trail FDA
# ---------------------------------------------------------
class JSONAuditHandler(logging.Handler):
    """Structured logging for FDA 21 CFR Part 11 compliance."""

    def __init__(self, log_path: str):
        super().__init__()
        self.log_path = log_path
        Path(log_path).parent.mkdir(parents=True, exist_ok=True)

    def emit(self, record: logging.LogRecord):
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "module": record.module,
            "message": self.format(record),
        }
        with open(self.log_path, "a") as f:
            f.write(json.dumps(entry) + "\n")


def setup_logger(log_dir: str) -> logging.Logger:
    logger = logging.getLogger("SaMD")
    logger.setLevel(logging.INFO)

    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s — %(message)s"))

    audit = JSONAuditHandler(os.path.join(log_dir, "audit_trail.jsonl"))

    logger.addHandler(console)
    logger.addHandler(audit)
    return logger


# ---------------------------------------------------------
# REPRODUCIBILITY
# ---------------------------------------------------------
def set_seed(seed: int = 42):
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.backends.cudnn.deterministic = True
    except ImportError:
        pass


# ---------------------------------------------------------
# PATH RESOLUTION
# ---------------------------------------------------------
CURR_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURR_DIR.parents[1]  # Pointe vers 'ai-module'
sys.path.insert(0, str(PROJECT_ROOT))

from src.pipeline.model_pipeline import MetabolicRiskPipeline
from src.pipeline.temporal_pipeline import TemporalFusionPipeline
from src.stacking.prs_encoder import PolygenicRiskEncoder
from src.stacking.stacking import ClinicalStackingEnsemble
# =========================================================
# SAMD TRAINER v2 — 2026
# =========================================================
class SaMDTrainer:
    """
    Production-grade SaMD trainer for diabetes risk prediction.

    Compliant with:
      - FDA 21 CFR Part 11 (audit trail, electronic signatures)
      - ISO 13485:2016 (quality management)
      - EU MDR 2017/745 (clinical evidence)
      - IEC 62304 (software lifecycle)
    """

    VERSION = "2.0.0"

    def __init__(self, config_path: str):
        with open(config_path, "r") as f:
            self.config = yaml.safe_load(f)

        self.run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self.model_dir = Path(PROJECT_ROOT) / self.config["model"]["save_dir"] / self.run_id
        self.artifact_dir = self.model_dir / "artifacts"
        self.artifact_dir.mkdir(parents=True, exist_ok=True)

        self.logger = setup_logger(str(self.model_dir / "logs"))
        self.logger.info(f"SaMD Trainer v{self.VERSION} initialized — run_id={self.run_id}")

        set_seed(self.config["random_seed"])

        # MLflow configuration
        if "mlflow" in self.config:
            mlflow.set_tracking_uri(self.config["mlflow"].get("tracking_uri", "mlruns/"))

        self.data_path = Path(PROJECT_ROOT) / self.config["data"]["path"]
        self.ext_path = Path(PROJECT_ROOT) / self.config["data"].get("external_val_path", "")
        self.prs_path = Path(PROJECT_ROOT) / self.config["data"].get("prs_path", "")

    # --------------------------------------------------
    # DATA — avec intégrité SHA-256 + PRS
    # --------------------------------------------------
    def load_data(self) -> Tuple:
        """Load data with SHA-256 integrity check and PRS integration."""
        self.logger.info(f"Loading data from {self.data_path}")

        df = pd.read_csv(self.data_path)

        # Data integrity hash (FDA traceability)
        sha256 = hashlib.sha256(df.to_json().encode()).hexdigest()
        self.logger.info(f"Data SHA-256: {sha256}")
        (self.model_dir / "data_integrity.json").write_text(
            json.dumps({"path": str(self.data_path), "sha256": sha256, "rows": len(df), "cols": len(df.columns)})
        )

        # Intégration Polygenic Risk Score
        if self.prs_path.exists():
            prs_encoder = PolygenicRiskEncoder()
            df = prs_encoder.merge(df, self.prs_path)
            self.logger.info("Polygenic Risk Score integrated.")

        X = df.drop(columns=["diabetes_target"])
        y = df["diabetes_target"]

        X_train, X_test, y_train, y_test = train_test_split(
            X, y,
            test_size=self.config["data"]["test_size"],
            stratify=y,
            random_state=self.config["random_seed"]
        )

        # SMOTE-NC : gestion du déséquilibre de classes sur variables mixtes
        categorical_features = [
            i for i, col in enumerate(X_train.columns)
            if X_train[col].nunique() < 10
        ]
        smote = SMOTENC(
            categorical_features=categorical_features,
            random_state=self.config["random_seed"]
        )
        X_train_res, y_train_res = smote.fit_resample(X_train, y_train)
        self.logger.info(f"SMOTE-NC resampling: {len(y_train)} → {len(y_train_res)} samples")

        return X_train_res, X_test, y_train_res, y_test, X_train, y_train

    # --------------------------------------------------
    # OPTUNA — TPE + Hyperband pruning
    # --------------------------------------------------
    def optimize(self, X: pd.DataFrame, y: pd.Series) -> Dict[str, Any]:
        """
        Bayesian hyperparameter optimization with TPE sampler
        and Hyperband early-stopping pruner.
        """
        self.logger.info("Starting Optuna optimization...")

        def objective(trial: optuna.Trial) -> float:
            params = {
                "estimator__learning_rate":    trial.suggest_float("lr", 1e-3, 0.15, log=True),
                "estimator__max_depth":        trial.suggest_int("depth", 3, 10),
                "estimator__n_estimators":     trial.suggest_int("n", 100, 500),
                "estimator__num_leaves":       trial.suggest_int("leaves", 20, 150),
                "estimator__min_child_samples":trial.suggest_int("min_child", 10, 100),
                "estimator__subsample":        trial.suggest_float("subsample", 0.6, 1.0),
                "estimator__colsample_bytree": trial.suggest_float("colsample", 0.6, 1.0),
                "estimator__reg_alpha":        trial.suggest_float("reg_alpha", 1e-8, 10.0, log=True),
                "estimator__reg_lambda":       trial.suggest_float("reg_lambda", 1e-8, 10.0, log=True),
            }

            pipeline = MetabolicRiskPipeline("lightgbm").get_pipeline()
            pipeline.set_params(**params)

            cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
            scores = cross_val_score(pipeline, X, y, cv=cv, scoring="roc_auc", n_jobs=-1)

            # Rapport intermédiaire pour Hyperband pruning
            trial.report(scores.mean(), step=1)
            if trial.should_prune():
                raise optuna.TrialPruned()

            return scores.mean()

        sampler = TPESampler(seed=self.config["random_seed"], multivariate=True)
        pruner = HyperbandPruner(min_resource=1, max_resource=5, reduction_factor=3)

        study = optuna.create_study(
            direction="maximize",
            sampler=sampler,
            pruner=pruner,
            study_name=f"SaMD_{self.run_id}"
        )
        study.optimize(
            objective,
            n_trials=self.config["tuning"]["n_trials"],
            show_progress_bar=True,
            n_jobs=1
        )

        self.logger.info(f"Best AUC: {study.best_value:.4f} | Params: {study.best_params}")

        # Sauvegarde des résultats Optuna
        df_trials = study.trials_dataframe()
        df_trials.to_csv(self.artifact_dir / "optuna_trials.csv", index=False)

        return study.best_params

    # --------------------------------------------------
    # ENSEMBLE — LightGBM + TFT stacking
    # --------------------------------------------------
    def build_ensemble(self, best_params: Dict, X_train: pd.DataFrame, y_train: pd.Series):
        """
        Two-level stacking ensemble:
          Level 0: LightGBM + Temporal Fusion Transformer
          Level 1: Logistic Regression meta-learner
        """
        self.logger.info("Building stacking ensemble (LightGBM + TFT)...")

        lgbm_pipeline = MetabolicRiskPipeline("lightgbm").get_pipeline()
        lgbm_pipeline.set_params(**best_params)

        tft_pipeline = TemporalFusionPipeline(
            hidden_size=self.config["model"].get("tft_hidden_size", 64),
            num_heads=self.config["model"].get("tft_heads", 4),
            dropout=self.config["model"].get("tft_dropout", 0.1),
        ).get_pipeline()

        ensemble = ClinicalStackingEnsemble(
            estimators=[("lgbm", lgbm_pipeline), ("tft", tft_pipeline)],
            final_estimator_type="logistic",
            cv=5,
        )
        return ensemble

    # --------------------------------------------------
    # CONFORMAL PREDICTION — incertitude certifiable
    # --------------------------------------------------
    def apply_conformal(self, base_model, X_train: pd.DataFrame, y_train: pd.Series):
        """
        Wrap model with MAPIE Conformal Prediction for
        guaranteed coverage (α=0.05 → 95% coverage).
        """
        self.logger.info("Applying Conformal Prediction wrapper (MAPIE)...")

        conformal_model = MapieClassifier(
            estimator=base_model,
            method="score",
            cv="prefit",
            random_state=self.config["random_seed"]
        )
        conformal_model.fit(X_train, y_train)
        return conformal_model

    # --------------------------------------------------
    # THRESHOLD — Youden + F1 optimal
    # --------------------------------------------------
    def find_threshold(self, y: pd.Series, probs: np.ndarray) -> Dict[str, float]:
        """Return both Youden J and F1-optimal thresholds."""
        fpr, tpr, thresholds = roc_curve(y, probs)

        # Youden J
        j_scores = tpr - fpr
        youden_th = float(thresholds[np.argmax(j_scores)])

        # F1 optimal
        f1_scores = []
        for th in thresholds:
            preds = (probs >= th).astype(int)
            tp = np.sum((preds == 1) & (y == 1))
            fp = np.sum((preds == 1) & (y == 0))
            fn = np.sum((preds == 0) & (y == 1))
            f1 = (2 * tp) / (2 * tp + fp + fn + 1e-9)
            f1_scores.append(f1)
        f1_th = float(thresholds[np.argmax(f1_scores)])

        self.logger.info(f"Threshold Youden={youden_th:.3f} | F1-optimal={f1_th:.3f}")
        return {"youden": youden_th, "f1_optimal": f1_th}

    # --------------------------------------------------
    # MÉTRIQUES CLINIQUES
    # --------------------------------------------------
    def clinical_metrics(self, y: pd.Series, probs: np.ndarray, threshold: float) -> Dict:
        """Extended clinical metrics beyond AUC."""
        preds = (probs >= threshold).astype(int)
        cm = confusion_matrix(y, preds)
        tn, fp, fn, tp = cm.ravel()

        sensitivity = tp / (tp + fn + 1e-9)
        specificity = tn / (tn + fp + 1e-9)
        ppv = tp / (tp + fp + 1e-9)
        npv = tn / (tn + fn + 1e-9)
        lr_plus = sensitivity / (1 - specificity + 1e-9)
        lr_minus = (1 - sensitivity) / (specificity + 1e-9)

        metrics = {
            "AUC_ROC":     round(roc_auc_score(y, probs), 4),
            "AUC_PR":      round(average_precision_score(y, probs), 4),
            "Brier_Score": round(brier_score_loss(y, probs), 4),
            "Sensitivity": round(sensitivity, 4),
            "Specificity": round(specificity, 4),
            "PPV":         round(ppv, 4),
            "NPV":         round(npv, 4),
            "LR+":         round(lr_plus, 4),
            "LR-":         round(lr_minus, 4),
        }
        return metrics

    # --------------------------------------------------
    # SHAP — TreeExplainer + waterfall + summary
    # --------------------------------------------------
    def shap_analysis(self, model, X: pd.DataFrame):
        """SHAP TreeExplainer with summary + waterfall plots."""
        self.logger.info("Computing SHAP values...")

        try:
            estimator = model.named_steps["estimator"]
            explainer = shap.TreeExplainer(estimator)
            shap_values = explainer.shap_values(X)

            # Summary plot
            fig, ax = plt.subplots(figsize=(10, 8))
            shap.summary_plot(shap_values, X, show=False)
            plt.tight_layout()
            plt.savefig(self.artifact_dir / "shap_summary.png", dpi=150, bbox_inches="tight")
            plt.close()

            # Feature importance par SHAP
            mean_abs_shap = np.abs(shap_values).mean(axis=0)
            importance_df = pd.DataFrame({
                "feature": X.columns,
                "mean_abs_shap": mean_abs_shap
            }).sort_values("mean_abs_shap", ascending=False)
            importance_df.to_csv(self.artifact_dir / "shap_importance.csv", index=False)

            np.save(self.artifact_dir / "shap_values.npy", shap_values)
            self.logger.info("SHAP analysis complete.")

        except Exception as e:
            self.logger.warning(f"SHAP analysis failed: {e}")

    # --------------------------------------------------
    # CALIBRATION PLOT — avec ECE
    # --------------------------------------------------
    def plot_calibration(self, y: pd.Series, probs: np.ndarray):
        """Calibration curve with Expected Calibration Error (ECE)."""
        prob_true, prob_pred = calibration_curve(y, probs, n_bins=10)

        # ECE
        n = len(y)
        ece = 0.0
        for i in range(len(prob_true)):
            bin_size = np.sum(
                (probs >= (i / 10)) & (probs < ((i + 1) / 10))
            )
            ece += (bin_size / n) * abs(prob_true[i] - prob_pred[i])

        fig, ax = plt.subplots(figsize=(7, 7))
        ax.plot(prob_pred, prob_true, marker='o', color="#E63946", linewidth=2, label=f"Model (ECE={ece:.3f})")
        ax.plot([0, 1], [0, 1], 'k--', label="Perfect calibration")
        ax.fill_between(prob_pred, prob_true, prob_pred, alpha=0.1, color="#E63946")
        ax.set_xlabel("Mean Predicted Probability")
        ax.set_ylabel("Fraction of Positives")
        ax.set_title("Calibration Curve")
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(self.artifact_dir / "calibration.png", dpi=150)
        plt.close()

        self.logger.info(f"Expected Calibration Error (ECE): {ece:.4f}")
        return ece

    # --------------------------------------------------
    # CONFORMAL COVERAGE CHECK
    # --------------------------------------------------
    def check_conformal_coverage(self, conformal_model, X_test: pd.DataFrame, y_test: pd.Series):
        """Verify conformal prediction guarantees empirical coverage."""
        _, y_ps = conformal_model.predict(X_test, alpha=0.05)
        coverage = classification_coverage_score(y_test.values, y_ps[:, :, 0])
        self.logger.info(f"Conformal coverage @ α=0.05: {coverage:.4f} (target ≥ 0.95)")
        return coverage

    # --------------------------------------------------
    # VALIDATION EXTERNE
    # --------------------------------------------------
    def external_validation(self, model, threshold: float) -> Optional[Dict]:
        """External validation on held-out cohort."""
        if not self.ext_path.exists():
            self.logger.warning("No external validation dataset found.")
            return None

        self.logger.info(f"External validation on {self.ext_path}")
        df = pd.read_csv(self.ext_path)
        X, y = df.drop(columns=["diabetes_target"]), df["diabetes_target"]

        probs = model.predict_proba(X)[:, 1]
        metrics = self.clinical_metrics(y, probs, threshold)

        self.logger.info(f"External validation metrics: {metrics}")
        (self.artifact_dir / "external_validation.json").write_text(json.dumps(metrics, indent=2))
        return metrics

    # --------------------------------------------------
    # MODEL CARD — FDA/MDR documentation
    # --------------------------------------------------
    def generate_model_card(self, metrics: Dict, thresholds: Dict, ece: float):
        """Generate Model Card compliant with FDA AI/ML guidance."""
        card = {
            "model_name": "SaMD Diabetes Risk Classifier",
            "version": self.VERSION,
            "run_id": self.run_id,
            "date": datetime.now(timezone.utc).isoformat(),
            "intended_use": "Decision support for Type 2 Diabetes risk stratification",
            "out_of_scope": ["Diagnosis", "Type 1 Diabetes", "Pediatric populations"],
            "training_data": {
                "path": str(self.data_path),
                "integrity_file": "data_integrity.json"
            },
            "performance": metrics,
            "thresholds": thresholds,
            "calibration": {"ECE": ece},
            "regulatory": {
                "standard": ["FDA 21 CFR Part 11", "ISO 13485:2016", "IEC 62304", "EU MDR 2017/745"],
                "classification": "SaMD - Class II",
                "audit_trail": "logs/audit_trail.jsonl"
            },
            "explainability": {
                "method": "SHAP TreeExplainer",
                "artifacts": ["shap_summary.png", "shap_importance.csv"]
            }
        }
        (self.model_dir / "model_card.json").write_text(json.dumps(card, indent=2))
        self.logger.info("Model card generated.")

    # --------------------------------------------------
    # TRAIN — pipeline complet
    # --------------------------------------------------
    def train(self):
        """Full training pipeline with MLflow experiment tracking."""

        mlflow.set_experiment("SaMD_DiabetesRisk_v2")

        with mlflow.start_run(run_name=self.run_id) as run:
            self.logger.info(f"MLflow Run ID: {run.info.run_id}")
            mlflow.log_param("trainer_version", self.VERSION)
            mlflow.log_param("config", self.config)

            # ── 1. Data ──────────────────────────────────────
            X_train, X_test, y_train, y_test, X_train_raw, y_train_raw = self.load_data()

            # ── 2. Hyperparameter Optimization ───────────────
            best_params = self.optimize(X_train, y_train)
            mlflow.log_params(best_params)

            # ── 3. Ensemble ───────────────────────────────────
            ensemble = self.build_ensemble(best_params, X_train, y_train)

            # ── 4. Isotonic Calibration (FDA recommended) ─────
            calibrated = CalibratedClassifierCV(ensemble, method="isotonic", cv=5)
            calibrated.fit(X_train, y_train)
            self.logger.info("Model trained and calibrated.")

            # ── 5. Conformal Prediction ───────────────────────
            conformal = self.apply_conformal(calibrated, X_train_raw, y_train_raw)
            coverage = self.check_conformal_coverage(conformal, X_test, y_test)

            # ── 6. Evaluation ─────────────────────────────────
            probs = calibrated.predict_proba(X_test)[:, 1]
            thresholds = self.find_threshold(y_test, probs)
            metrics = self.clinical_metrics(y_test, probs, thresholds["youden"])

            self.logger.info("\n" + "=" * 50)
            for k, v in metrics.items():
                self.logger.info(f"  {k}: {v}")
            self.logger.info("=" * 50)

            mlflow.log_metrics(metrics)
            mlflow.log_metric("conformal_coverage", coverage)

            # ── 7. SHAP ───────────────────────────────────────
            self.shap_analysis(ensemble.estimators_[0][1], X_test)

            # ── 8. Calibration plot ───────────────────────────
            ece = self.plot_calibration(y_test, probs)
            mlflow.log_metric("ECE", ece)

            # ── 9. External Validation ────────────────────────
            ext_metrics = self.external_validation(calibrated, thresholds["youden"])
            if ext_metrics:
                mlflow.log_metrics({f"ext_{k}": v for k, v in ext_metrics.items()})

            # ── 10. Model Card ────────────────────────────────
            self.generate_model_card(metrics, thresholds, ece)

            # ── 11. Save artifacts ────────────────────────────
            model_path = self.model_dir / "samd_model_v2.joblib"
            conformal_path = self.model_dir / "samd_conformal.joblib"
            joblib.dump(calibrated, model_path)
            joblib.dump(conformal, conformal_path)

            # Sync latest model for API
            latest_model_path = Path(PROJECT_ROOT) / "models" / "metabolic_model.joblib"
            latest_model_path.parent.mkdir(parents=True, exist_ok=True)
            joblib.dump(calibrated, latest_model_path)
            self.logger.info(f"Latest model synced for API: {latest_model_path}")

            mlflow.sklearn.log_model(calibrated, "calibrated_model")
            mlflow.log_artifacts(str(self.artifact_dir), artifact_path="artifacts")

            # MLflow Model Registry
            model_uri = f"runs:/{run.info.run_id}/calibrated_model"
            mlflow.register_model(model_uri, "SaMD_DiabetesRisk")

            self.logger.info(f"Model saved: {model_path}")
            self.logger.info(f"Conformal model saved: {conformal_path}")
            self.logger.info("Training complete.")

        return calibrated, conformal, metrics


# =========================================================
# MAIN
# =========================================================
if __name__ == "__main__":
    config_path = Path(PROJECT_ROOT) / "config.yaml"
    trainer = SaMDTrainer(str(config_path))
    trainer.train()